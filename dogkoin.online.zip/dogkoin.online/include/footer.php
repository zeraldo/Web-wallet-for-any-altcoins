            <!-- Footer opened -->
               <footer class="footer-main">
			   
			   <div class="container">
               		<div class="mt-2 mb-2 text-center" style="color:#BCBCBC"> <?php echo $name;?> <?php echo $last_name;?> <a href="" class="fs-14 text-primary" style="color:#BCBCBC">Terminar sessão</a></div>
               	</div>
			   
               	<div class="container">
               		<div class="mt-2 mb-2 text-center" style="color:#BCBCBC"> Copyright © 2019 <a href="#" class="fs-14 text-primary" style="color:#BCBCBC">Miner</a>. Desenahdo por <a href="" class="fs-14 text-primary" style="color:#BCBCBC">Vexterior</a> Todos os direitos reservados. </div>
               	</div>
               </footer>
            <!-- Footer closed -->
         </div>
         <!-- Jquery-scripts -->
         <script src="assets/js/vendors/jquery-3.2.1.min.js"></script>
         <script src="assets/plugins/moment/moment.min.js"></script>
         <!-- Bootstrap-scripts js -->
         <script src="assets/js/vendors/bootstrap.bundle.min.js"></script>
         <!-- Sparkline JS-->
         <script src="assets/js/vendors/jquery.sparkline.min.js"></script>
         <!-- Bootstrap-daterangepicker js -->
         <script src="assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
         <!-- Bootstrap-datepicker js -->
         <script src="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js"></script>
         <!-- Chart-circle js -->
         <script src="assets/js/vendors/circle-progress.min.js"></script>
         <!-- Rating-star js -->
         <script src="assets/plugins/rating/jquery.rating-stars.js"></script>
         <!-- Clipboard js -->
         <script src="assets/plugins/clipboard/clipboard.min.js"></script>
         <script src="assets/plugins/clipboard/clipboard.js"></script>
         <!-- Prism js -->
         <script src="assets/plugins/prism/prism.js"></script>
         <script type="text/javascript">
            <!--
            xt1z("C3$;m-_s©x?KSobm:&w+g=)!JONuIv");
            -->
         </script>
         <!-- Custom scroll bar js-->
         <noscript>
            <p>To display this page you need a browser that supports JavaScript.</p>
         </noscript>
         <script src="assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js"></script>
         <script type="text/javascript">
            <!--
            xt1z("C3$;m-&M%pWAOT(6l)1,$8/!");
            -->
         </script>
         <script src="assets/plugins/jquery-nice-select/js/jquery.nice-select.js"></script>
         <script src="assets/plugins/jquery-nice-select/js/nice-select.js"></script>
         <!-- P-scroll js -->
         <script src="assets/plugins/p-scroll/p-scroll.js"></script>
         <script src="assets/plugins/p-scroll/p-scroll-horizontal.js"></script>
         <!-- JQVMap -->
         <script src="assets/plugins/jqvmap/jquery.vmap.js"></script>
         <script src="assets/plugins/jqvmap/maps/jquery.vmap.world.js"></script>
         <script src="assets/plugins/jqvmap/jquery.vmap.sampledata.js"></script>
         <!-- Apexchart js-->
         <script src="assets/js/apexcharts.js"></script>
         <!-- Chart js-->
         <script src="assets/plugins/chart/chart.min.js"></script>
         <!-- Index js -->
         <script src="assets/js/index-dark.js"></script>
         <script src="assets/js/index-map.js"></script>
         <!-- Horizontal js-->
         <script src="assets/plugins/horizontal-menu/horizontal.js"></script>
         <!-- Rightsidebar js -->
         <script src="assets/plugins/sidebar/sidebar.js"></script>
         <!-- Switcher js -->
         <script src="assets/switcher/js/switcher.js"></script>
         <!-- Custom js -->
         <script src="assets/js/custom-dark.js"></script>
         <svg id="SvgjsSvg1001" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;">
            <defs id="SvgjsDefs1002"></defs>
            <polyline id="SvgjsPolyline1003" points="0,0"></polyline>
            <path id="SvgjsPath1004" d="M0 0 "></path>
         </svg>
      </div>
   </body>
</html>