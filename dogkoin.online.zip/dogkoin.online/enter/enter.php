<?php 
ini_set('display_errors', 0 );
error_reporting(0);

//Verifico se o usuário está logado no sistema
if ( !isset ($_SESSION["user"]) || $_SESSION["user"] !=
TRUE ) {

require '../include/wew.php';
 
 if ($_SERVER['REQUEST_METHOD'] == 'POST') 

{
    if (isset($_POST['login'])) {
		
$email = $mysqli->escape_string($_POST['email']);

$result = $mysqli->query("SELECT * FROM users WHERE email='$email'");

if ( $result->num_rows == 0 ){ // User doesn't exist 
//Aqui o email não existe
echo '909'; 
}
else { // User exists
    $user = $result->fetch_assoc();
//Pegando o nome do usuario
   $nome = $user['name'];
   
   $id_us = $user['id_one'];
   
    if ( md5($_POST['password']) == $user['password']) {
        
		//Verficar se o usuario é o administrador do site
	
$result = $mysqli->query("SELECT * FROM users_adm WHERE email='$email'");

if ( $result->num_rows == 0 ){ // User doesn't exist 
//Aqui não é  o adm 
$_SESSION['user'] = $email;

//Pegar a data do usuario
require '../include/data.php';

//Incluir informaçoes do usuario, ip, navegador e o sistema operacional
require '../include/info_user.php'; 


//Envio de email
require '../mail/conta-acessada.php'; 

//logado com sucesso
echo '100';

}
 
   }
    else {
		
		//Aqui a senha esta incorreta
		//Vamos verificar se é a senha alterada
		
$nconsulta = "SELECT * FROM forgotpass WHERE id_user='$id_us'";

if (!$resultado = $mysqli->query($nconsulta)) {
    echo ' Falha na consulta: '. $mysqli->error;
    $mysqli->close(); 
}
else{
    while ($row = $resultado->fetch_assoc()){   
   $pass = $row['code'];
   $data_inicial = $row['datasend'];
   
    }
} 
  if ( md5($_POST['password']) == $pass) {
	  
	   //Aqui a senha é igual com a senha de recuperaçao
	   
      $data_final = date("20y-m-d H:i:s");
	   //Aqui verificamos quanto tempo a senha de recuperaço existe
	      $entrada = strtotime( ''.$data_inicial.'' );
    $saida   = strtotime( ''.$data_final.'' );
    $diferenca = $saida - $entrada;
/*  printf( '%d', $diferenca/3600, $diferenca/60%60 ); */
$z = $diferenca/3600;
 
$zz = $z;
if ( $zz < 0.50 ) {

	  
//apagar a senha de recuperaçao do usuario
 
 $sql = "DELETE FROM forgotpass WHERE id_user='$id_us'";

if (!$mysqli->query($sql)) {
    echo " Falha ao executar a consulta: \"$consulta\" <br>" . $mysqli->error;
   } 
//final apagar a senha de recuperaçao do usuario

//Alterar a senha do usuario para a senha gerada

 
$password_b = $mysqli->escape_string($senha);

//atualizar as informações na base de dados
  $mysqli->query("UPDATE users SET password='$pass' WHERE id_one='$id_us'") or die($mysqli->error);

	  $_SESSION['user'] = $email;

//Pegar a data do usuario
require '../include/data.php';

//Incluir informaçoes do usuario, ip, navegador e o sistema operacional
require '../include/info_user.php'; 

//Envio de email
require '../mail/conta-acessada.php'; 

//logado com sucesso
echo '100'; 

    }
	 
	 else
	{
//Código de recuperaçao invalido		
echo '99';  
   }
    }
	else
	{
//Senha incorreta		
echo '109'; 

   }
  }
 }
}
        
 } 
 }
else {
//Logado com sucesso
echo '100';
}
