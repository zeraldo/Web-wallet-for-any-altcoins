<?php 
ini_set('display_errors', 0 );
error_reporting(-0);
 
//Aqui o usuario esta logado 

require '../include/wew.php';

$id_one = mt_rand(10000000,99999999);

$usd = $mysqli->escape_string($_POST['dolar']);

$nomoeda = $mysqli->escape_string($_POST['moeda']);

$moedanacio = $mysqli->escape_string($_POST['kwanza']);

$telefone = $mysqli->escape_string($_POST['telefone']);

$endereco =  $mysqli->escape_string($_POST['endereco']);

$telefone_b = $mysqli->escape_string($_POST['telefone_b']);

$email = $mysqli->escape_string($_POST['email']);

$tmoeda = 'tmoeda';

$nome = $mysqli->escape_string($_POST['nome´']);

$status = 0;

$data = date("20y-m-d H:i:s");

$mysqli->query("INSERT INTO compra (nomoeda, endereco, usd, moeda,  nome, email, telefone, telefone_b, data, id_one, status) " 
            . "VALUES ('$nomoeda','$endereco','$usd','$moedanacio','$nome','$email','$telefone','$telefone_b','$data','$id_one','$status')");
//Enviar notificaçao no admin
$email2 = 'zuacandido@gmail.com';
require '../mail/nova-compra.php'; 

echo '100';
?>