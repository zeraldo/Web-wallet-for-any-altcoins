<?php 
//ini_set('display_errors', 0 );
//error_reporting(-0);
 
session_start();
 
//Aqui o usuario esta logado 
require '../include/wew.php';

$id_one = mt_rand(10000000,99999999);

$nomoeda = $mysqli->escape_string($_POST['moeda']);

$moedanacio = $mysqli->escape_string($_POST['kwanza']);

$tmoeda = 'tmoeda';

$endereco =  $mysqli->escape_string($_POST['endereco']);

$usd = $mysqli->escape_string($_POST['dolar']);

$nome = 'nome';

$telefone = $mysqli->escape_string($_POST['telefone']);

$telefone_alter = $mysqli->escape_string($_POST['telefone_b']);

$email = $_SESSION['user'];

$status = 0;

$data = date("20y-m-d H:i:s");

$mysqli->query("INSERT INTO compra (nomoeda, endereco, usd, moeda,  nome, email, telefone, telefone_b, data, id_one, status) " 
            . "VALUES ('$nomoeda','$endereco','$usd','$moedanacio','$nome','$email','$telefone','$telefone_alter','$data','$id_one','$status')");

echo '100';			

?>