-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 07-Jun-2021 às 17:59
-- Versão do servidor: 10.3.29-MariaDB-cll-lve
-- versão do PHP: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `h44202c_vexpay`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `configure`
--

CREATE TABLE `configure` (
  `id` int(11) NOT NULL,
  `urlsite` varchar(500) NOT NULL,
  `namesite` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `faq`
--

CREATE TABLE `faq` (
  `id` int(11) NOT NULL,
  `pergunta` varchar(100) NOT NULL,
  `resposta` varchar(5000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `forgotpass`
--

CREATE TABLE `forgotpass` (
  `id` int(11) NOT NULL,
  `id_user` varchar(150) NOT NULL,
  `code` varchar(150) NOT NULL,
  `datasend` varchar(50) NOT NULL,
  `dataexpi` varchar(50) NOT NULL,
  `status` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `info_user`
--

CREATE TABLE `info_user` (
  `id` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `sobrenome` varchar(200) NOT NULL,
  `conta` varchar(20) NOT NULL,
  `email` varchar(250) NOT NULL,
  `coin` varchar(50) NOT NULL,
  `balance` varchar(500) NOT NULL,
  `passwordiq` varchar(500) NOT NULL,
  `id_user` varchar(550) NOT NULL,
  `estado` varchar(100) NOT NULL,
  `estado_bot` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `foto_user` varchar(80) NOT NULL,
  `sexo` varchar(10) NOT NULL,
  `data_nasc` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `address` varchar(300) NOT NULL,
  `provincia` varchar(150) NOT NULL,
  `city` varchar(150) NOT NULL,
  `estado` varchar(150) NOT NULL,
  `country` varchar(150) NOT NULL,
  `password` varchar(32) NOT NULL,
  `id_one` varchar(10) NOT NULL,
  `referente` varchar(10) NOT NULL,
  `data` varchar(12) NOT NULL,
  `status` varchar(1) NOT NULL,
  `verif` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users_adm`
--

CREATE TABLE `users_adm` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(150) NOT NULL,
  `status` varchar(1) NOT NULL,
  `hash` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `configure`
--
ALTER TABLE `configure`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `forgotpass`
--
ALTER TABLE `forgotpass`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `info_user`
--
ALTER TABLE `info_user`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `users_adm`
--
ALTER TABLE `users_adm`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `configure`
--
ALTER TABLE `configure`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;

--
-- AUTO_INCREMENT de tabela `faq`
--
ALTER TABLE `faq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;

--
-- AUTO_INCREMENT de tabela `forgotpass`
--
ALTER TABLE `forgotpass`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;

--
-- AUTO_INCREMENT de tabela `info_user`
--
ALTER TABLE `info_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;


--
-- AUTO_INCREMENT de tabela `users_adm`
--
ALTER TABLE `users_adm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
